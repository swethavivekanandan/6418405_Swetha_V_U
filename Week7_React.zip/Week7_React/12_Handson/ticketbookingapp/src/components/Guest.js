function Guest() {
  return <h2>Welcome Mighty Guest!!! You can browse flights below.</h2>;
}

export default Guest;
