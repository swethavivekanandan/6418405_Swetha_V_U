function Login(props) {
  return (
    <button onClick={props.onClick}>
      Login
    </button>
  );
}

export default Login;