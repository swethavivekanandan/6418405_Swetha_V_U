function Logout(props) {
  return (
    <button onClick={props.onClick}>
      Logout
    </button>
  );
}

export default Logout;