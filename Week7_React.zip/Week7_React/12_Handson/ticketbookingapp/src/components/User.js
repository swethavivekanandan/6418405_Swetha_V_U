function User() {
  return <h2>Welcome back! You can now book your tickets.</h2>;
}

export default User;